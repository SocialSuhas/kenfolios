# KenFolios Business Community Landing

## Structure
- /community/index.html -> Main landing page
- /community/thank-you.html -> Confirmation page after payment

## Deployment
1. Push this repository to GitHub.
2. Connect GitHub repo to Cloudflare Pages.
3. Set output folder to /community.
4. Map custom domain or subdomain as needed.

Edit `YOUR_PIXEL_ID` and `YOUR_PAYMENT_LINK` in the HTML files before deploying.
